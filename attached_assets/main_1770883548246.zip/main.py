from fastapi import FastAPI, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from datetime import datetime
from datetime import date
import snowflake.connector
from openai import OpenAI
import json
import os

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# --- CONFIG & CLIENTS ---
# Replace with your actual credentials or use environment variables
SF_CONFIG = {
    "user": "feedbackpro",
    "password": "Staticchair@428",
    "account": "nvhwuxc-xq66159",
    "warehouse": "COMPUTE_WH",
    "database": "TS_PULSE_DB",
    "schema": "PUBLIC"
}

client = OpenAI(api_key="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")

def get_db():
    conn = snowflake.connector.connect(**SF_CONFIG)
    try:
        yield conn
    finally:
        conn.close()

# --- AI LOGIC ---
def analyze_feedback(text):
    prompt = f"Analyze this employee feedback: '{text}'. Return JSON: {{'sentiment': float, 'summary': string}}"
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "system", "content": "You are an HR AI. Sentiment is 0-1."},
                  {"role": "user", "content": prompt}],
        response_format={ "type": "json_object" }
    )
    return json.loads(response.choices[0].message.content)

# --- ROUTES ---

@app.get("/", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
async def login(email: str = Form(...), password: str = Form(...), db=Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT ROLE FROM USERS WHERE EMAIL=%s AND PASSWORD_HASH=%s", (email, password))
    user = cursor.fetchone()
    if user:
        return RedirectResponse(url=f"/dashboard?email={email}", status_code=303)
    raise HTTPException(status_code=401, detail="Invalid Credentials")

@app.get("/success", response_class=HTMLResponse)
async def success_page(request: Request, email: str = None):
    return templates.TemplateResponse("success.html", {"request": request, "email": email})

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request, email: str, period: str = None, db=Depends(get_db)):
    cursor = db.cursor(snowflake.connector.DictCursor)
    
    # 1. Get User Details
    cursor.execute("SELECT * FROM USERS WHERE EMAIL=%s", (email,))
    user_info = cursor.fetchone()
    
    if not user_info:
        return RedirectResponse(url="/?error=user_not_found")

    # Initialize period and fetch available periods globally for all roles
    if not period:
        period = datetime.now().strftime("%b-%Y")
        
    cursor.execute("""
        SELECT SUBMISSION_PERIOD 
        FROM FEEDBACK 
        GROUP BY SUBMISSION_PERIOD 
        ORDER BY MAX(SUBMITTED_AT) DESC
    """)
    available_periods = [row['SUBMISSION_PERIOD'] for row in cursor.fetchall()]

    # 2. Handle EMPLOYEE Role
    if user_info['ROLE'] == 'EMPLOYEE':
        # FIXED: Join with MANAGER_REVIEWS to get the real status
        cursor.execute("""
            SELECT f.*, r.FEEDBACK_ID as REVIEWED
            FROM FEEDBACK f
            LEFT JOIN MANAGER_REVIEWS r ON f.ID = r.FEEDBACK_ID
            WHERE f.EMAIL = %s 
            ORDER BY f.SUBMITTED_AT DESC
        """, (email,))
        history = cursor.fetchall()

        # Check if user already submitted for the SELECTED period
        cursor.execute("SELECT ID FROM FEEDBACK WHERE EMAIL=%s AND SUBMISSION_PERIOD=%s", (email, period))
        already_submitted = cursor.fetchone() is not None

        return templates.TemplateResponse("employee_dashboard.html", {
            "request": request, 
            "user": user_info, 
            "history": history,
            "already_submitted": already_submitted,
            "current_period": period,
            "available_periods": available_periods # Necessary for potential dropdowns
        })

    # 3. Handle MANAGER Role
    elif user_info['ROLE'] == 'MANAGER':
        # (This block is already quite solid, keeping it for context)
        cursor.execute("SELECT ID FROM FEEDBACK WHERE EMAIL=%s AND SUBMISSION_PERIOD=%s", (email, period))
        already_submitted = cursor.fetchone() is not None

        cursor.execute("""
            SELECT f.*, u.FULL_NAME, u.DEPT_CODE, r.FEEDBACK_ID as REVIEWED
            FROM FEEDBACK f
            JOIN USERS u ON f.EMAIL = u.EMAIL
            LEFT JOIN MANAGER_REVIEWS r ON f.ID = r.FEEDBACK_ID
            WHERE u.MANAGER_EMAIL = %s AND f.SUBMISSION_PERIOD = %s
        """, (email, period))
        team_feedback = cursor.fetchall()
        
        avg_sat = 0
        risk_count = 0
        if team_feedback:
            total_sat = sum(row['SAT_SCORE_INT'] for row in team_feedback)
            avg_sat = round(total_sat / len(team_feedback), 1)
            risk_count = sum(1 for row in team_feedback if row['MOOD_SCORE_INT'] <= 2)

        return templates.TemplateResponse("manager_dashboard.html", {
            "request": request,
            "user": user_info,
            "team": team_feedback,
            "current_period": period,
            "available_periods": available_periods,
            "already_submitted": already_submitted,
            "avg_sat": avg_sat,
            "risk_count": risk_count
        })

    # 4. Handle Senior Management
    elif user_info['ROLE'] == 'SENIOR_MGMT':
        return RedirectResponse(url=f"/senior_dashboard?email={email}&period={period}")
        
@app.get("/feedback_form", response_class=HTMLResponse)
async def feedback_form(request: Request, email: str, db=Depends(get_db)):
    cursor = db.cursor(snowflake.connector.DictCursor)
    
    # Fetch last 6 months of mood scores
    cursor.execute("""
        SELECT MOOD_SCORE_INT 
        FROM FEEDBACK 
        WHERE EMAIL = %s 
        ORDER BY SUBMITTED_AT DESC 
        LIMIT 6
    """, (email,))
    history = cursor.fetchall()
    
    # Extract scores
    mood_history = [row['MOOD_SCORE_INT'] for row in history]
    
    # Defensive logic for "Stability"
    if not mood_history:
        stability = "New Joiner"
        mood_history = [] # Explicit empty list
    elif len(mood_history) < 3:
        stability = "Establishing..."
    else:
        variance = max(mood_history) - min(mood_history)
        stability = "High" if variance <= 1 else "Moderate" if variance == 2 else "Volatile"

    return templates.TemplateResponse("feedback_form.html", {
        "request": request, 
        "email": email, 
        "mood_history": mood_history[::-1], # Reverse for chronological display
        "stability": stability
    })
    

@app.post("/submit_feedback")
async def submit(
    email: str = Form(...),
    dept: str = Form(...),
    sat: str = Form(...),
    mood: str = Form(...),
    acc: str = Form(...),
    dis: str = Form(...),
    blockers: str = Form(...),
    supp: str = Form(...),
    wlb: str = Form(...),
    workload: str = Form(...),
    mentoring: str = Form(...),
    sug: str = Form(...),
    pto: str = Form(...),
    goals: str = Form(...),
    db=Depends(get_db)
):
    # 1. Map Text to Integers for Analytics
    SAT_MAP = {
        "Very satisfied": 10, "Somewhat satisfied": 8, 
        "Neither satisfied nor dissatisfied": 5, 
        "Somewhat dissatisfied": 3, "Very dissatisfied": 0
    }
    MOOD_MAP = {
        "Great": 5, "Good": 4, "Neutral": 3, "Challenged": 2, "Burned out": 1
    }
    
    sat_int = SAT_MAP.get(sat, 5)
    mood_int = MOOD_MAP.get(mood, 3)
    current_period = datetime.now().strftime("%b-%Y")

    # 2. Intelligence Layer: OpenAI Sentiment Analysis
    # We combine key qualitative fields for a holistic sentiment score
    text_to_analyze = f"Accomplishments: {acc}. Disappointments: {dis}. Blockers: {blockers}"
    try:
        ai_data = analyze_feedback(text_to_analyze) # Uses the function we built earlier
        sentiment_score = ai_data['sentiment']
        ai_summary = ai_data['summary']
    except:
        sentiment_score = 0.5
        ai_summary = "AI analysis currently unavailable."

    # 3. Snowflake Persistence
    cursor = db.cursor()
    query = """
        INSERT INTO FEEDBACK (
            EMAIL, SUBMISSION_PERIOD, SAT_SCORE_RAW, SAT_SCORE_INT, 
            MOOD_SCORE_RAW, MOOD_SCORE_INT, ACCOMPLISHMENTS, DISAPPOINTMENTS, 
            BLOCKERS_RISKS, SUPPORT_NEEDS, WLB_COMMENT, WORKLOAD_COMMENT, 
            MENTORING_JUNIORS, SUGGESTIONS, PTO_PLAN, GOAL_PROGRESS, 
            AI_SENTIMENT_SCORE, AI_SUMMARY
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    
    cursor.execute(query, (
        email, current_period, sat, sat_int, mood, mood_int,
        acc, dis, blockers, supp, wlb, workload, 
        mentoring, sug, pto, goals, sentiment_score, ai_summary
    ))
    db.commit()
    
    return RedirectResponse(url=f"/success?email={email}", status_code=303)
    
@app.post("/save_manager_review")
async def save_review(
    feedback_id: int = Form(...),
    manager_email: str = Form(...),
    mgr_sat: str = Form(None),
    mgr_mood: str = Form(None),
    mgr_acc: str = Form(None),
    mgr_dis: str = Form(None),
    mgr_blockers: str = Form(None),
    mgr_supp: str = Form(None),
    mgr_wlb: str = Form(None),
    mgr_workload: str = Form(None),
    mgr_mentoring: str = Form(None),
    mgr_sug: str = Form(None),
    mgr_pto: str = Form(None),
    mgr_goals: str = Form(None),
    db=Depends(get_db)
):
    cursor = db.cursor()
    # Using MERGE ensures the "Edit" functionality works by updating existing rows
    query = """
        MERGE INTO MANAGER_REVIEWS AS target
        USING (SELECT %s AS FID) AS source
        ON target.FEEDBACK_ID = source.FID
        WHEN MATCHED THEN UPDATE SET 
            MGR_SAT_COMMENT = %s, MGR_MOOD_COMMENT = %s, MGR_ACC_COMMENT = %s, 
            MGR_DIS_COMMENT = %s, MGR_BLOCKERS_COMMENT = %s, MGR_SUPPORT_COMMENT = %s,
            MGR_WLB_COMMENT = %s, MGR_WORKLOAD_COMMENT = %s, MGR_MENTORING_COMMENT = %s,
            MGR_SUGGESTIONS_COMMENT = %s, MGR_PTO_COMMENT = %s, MGR_GOAL_COMMENT = %s,
            LAST_EDITED = CURRENT_TIMESTAMP()
        WHEN NOT MATCHED THEN INSERT (
            FEEDBACK_ID, MGR_EMAIL, MGR_SAT_COMMENT, MGR_MOOD_COMMENT, 
            MGR_ACC_COMMENT, MGR_DIS_COMMENT, MGR_BLOCKERS_COMMENT, 
            MGR_SUPPORT_COMMENT, MGR_WLB_COMMENT, MGR_WORKLOAD_COMMENT, 
            MGR_MENTORING_COMMENT, MGR_SUGGESTIONS_COMMENT, MGR_PTO_COMMENT, MGR_GOAL_COMMENT
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    cursor.execute(query, (
        feedback_id, mgr_sat, mgr_mood, mgr_acc, mgr_dis, mgr_blockers, 
        mgr_supp, mgr_wlb, mgr_workload, mgr_mentoring, mgr_sug, mgr_pto, mgr_goals,
        feedback_id, manager_email, mgr_sat, mgr_mood, mgr_acc, mgr_dis, mgr_blockers, 
        mgr_supp, mgr_wlb, mgr_workload, mgr_mentoring, mgr_sug, mgr_pto, mgr_goals
    ))
    db.commit()
    return RedirectResponse(url=f"/dashboard?email={manager_email}", status_code=303) 
    
@app.get("/review_feedback/{feedback_id}", response_class=HTMLResponse)
async def review_feedback_page(request: Request, feedback_id: int, manager: str, db=Depends(get_db)):
    cursor = db.cursor(snowflake.connector.DictCursor)
    
    # 1. Fetch the specific employee feedback
    cursor.execute("""
        SELECT f.*, u.FULL_NAME, u.DEPT_CODE 
        FROM FEEDBACK f
        JOIN USERS u ON f.EMAIL = u.EMAIL
        WHERE f.ID = %s
    """, (feedback_id,))
    feedback_data = cursor.fetchone()
    
    # 2. Fetch any existing manager review for this feedback (for editing)
    cursor.execute("SELECT * FROM MANAGER_REVIEWS WHERE FEEDBACK_ID = %s", (feedback_id,))
    existing_review = cursor.fetchone()

    return templates.TemplateResponse("review.html", {
        "request": request,
        "feedback": feedback_data,
        "review": existing_review or {}, # Pass empty dict if no review exists yet
        "manager_email": manager
    })    
    
@app.get("/employee_progress/{emp_email}", response_class=HTMLResponse)
async def employee_progress(
    request: Request, 
    emp_email: str, 
    email: str = None,   
    source: str = "mgr", 
    db=Depends(get_db)
):
    cursor = db.cursor(snowflake.connector.DictCursor)
    
    # --- STEP 1: Fetch User Meta ---
    cursor.execute("""
        SELECT FULL_NAME, DEPT_CODE, MANAGER_EMAIL 
        FROM USERS 
        WHERE EMAIL = %s
    """, (emp_email,))
    user_meta = cursor.fetchone()
    
    if not user_meta:
        raise HTTPException(status_code=404, detail="Employee record not found")

    # --- STEP 2: Fetch Goal History ---
    cursor.execute("""
        SELECT SUBMISSION_PERIOD, GOAL_PROGRESS, 
               LENGTH(GOAL_PROGRESS) as GOAL_DEPTH
        FROM FEEDBACK 
        WHERE EMAIL = %s 
        ORDER BY SUBMITTED_AT DESC 
        LIMIT 4
    """, (emp_email,))
    goal_history = cursor.fetchall()
    
    # --- STEP 3: Fetch Holistic History ---
    cursor.execute("""
        SELECT 
            f.*, 
            r.MGR_ACC_COMMENT, r.MGR_GOAL_COMMENT, r.MGR_SUGGESTIONS_COMMENT,
            r.MGR_WLB_COMMENT, r.MGR_WORKLOAD_COMMENT, r.MGR_BLOCKERS_COMMENT,
            r.MGR_SUPPORT_COMMENT, r.MGR_MENTORING_COMMENT, r.MGR_PTO_COMMENT,
            r.LAST_EDITED as REVIEW_DATE
        FROM FEEDBACK f
        LEFT JOIN MANAGER_REVIEWS r ON f.ID = r.FEEDBACK_ID
        WHERE f.EMAIL = %s
        ORDER BY f.SUBMITTED_AT DESC
    """, (emp_email,))
    history = cursor.fetchall()
    
    # --- STEP 4: Fetch Departmental Benchmarks ---
    cursor.execute("""
        SELECT 
            f.SUBMISSION_PERIOD, 
            ROUND(AVG(f.SAT_SCORE_INT), 1) as DEPT_AVG_SAT
        FROM FEEDBACK f
        JOIN USERS u ON f.EMAIL = u.EMAIL
        WHERE u.DEPT_CODE = %s
        GROUP BY f.SUBMISSION_PERIOD
        ORDER BY MAX(f.SUBMITTED_AT) DESC
        LIMIT 12
    """, (user_meta['DEPT_CODE'],))
    dept_stats = cursor.fetchall()
    dept_avg_map = {row['SUBMISSION_PERIOD']: row['DEPT_AVG_SAT'] for row in dept_stats}
    
    # --- STEP 5: Metadata for Navigation ---
    dept = user_meta['DEPT_CODE'] if user_meta else "ALL"
    
    # --- STEP 6: Calculate Metrics ---
    tenure_months = len(history)
    avg_sat = 0
    if tenure_months > 0:
        avg_sat = round(sum(row['SAT_SCORE_INT'] for row in history) / tenure_months, 1)
    ai_summary = f"Employee shows steady progress over {tenure_months} months." 

    # --- NEW STEP 7: Fetch Manager Action Items ---
    cursor.execute("""
        SELECT ACTION_ID, TASK_DESCRIPTION, STATUS, DUE_DATE, CREATED_AT 
        FROM MANAGER_ACTIONS 
        WHERE EMP_EMAIL = %s 
        ORDER BY CASE WHEN STATUS = 'Pending' THEN 1 ELSE 2 END, CREATED_AT DESC
    """, (emp_email,))
    actions_list = cursor.fetchall()

    # --- STEP 8: Return Response (Updated with actions) ---
    return templates.TemplateResponse("employee_progress.html", {
        "request": request,
        "history": history,      
        "user": user_meta, 
        "avg_sat": avg_sat,
        "goal_history": goal_history,
        "tenure_months": tenure_months,
        "ai_summary": ai_summary,
        "today_date": date.today(),
        "source": source,        
        "dept": dept,            
        "email": email if email else emp_email,          
        "emp_email": emp_email,   
        "dept_avg_map": dept_avg_map,
        "actions": actions_list # Passed to the HTML loop
    })
    
    
@app.get("/senior_dashboard", response_class=HTMLResponse)
async def senior_dashboard(request: Request, email: str, period: str = None, dept: str = None, db=Depends(get_db)):
    cursor = db.cursor(snowflake.connector.DictCursor)
    
    if not period:
        period = datetime.now().strftime("%b-%Y")

    # Fetch available periods for the dropdown
    cursor.execute("""
        SELECT SUBMISSION_PERIOD FROM FEEDBACK 
        GROUP BY SUBMISSION_PERIOD ORDER BY MAX(SUBMITTED_AT) DESC
    """)
    available_periods = [row['SUBMISSION_PERIOD'] for row in cursor.fetchall()]

    if not dept:
        # --- ORG VIEW: General Stats ---
        cursor.execute("SELECT AVG(SAT_SCORE_INT) as SAT, COUNT(*) as TOTAL FROM FEEDBACK WHERE SUBMISSION_PERIOD=%s", (period,))
        stats = cursor.fetchone()
        
        # --- ORG VIEW: Leader Accountability (The New Product Feature) ---
        cursor.execute("""
            SELECT 
                u.MANAGER_EMAIL, 
                COUNT(a.ACTION_ID) as TOTAL_TASKS,
                SUM(CASE WHEN a.STATUS = 'Pending' THEN 1 ELSE 0 END) as PENDING,
                SUM(CASE WHEN a.STATUS = 'Pending' AND a.DUE_DATE < CURRENT_DATE() THEN 1 ELSE 0 END) as OVERDUE
            FROM USERS u
            LEFT JOIN MANAGER_ACTIONS a ON u.EMAIL = a.EMP_EMAIL
            WHERE u.MANAGER_EMAIL IS NOT NULL
            GROUP BY u.MANAGER_EMAIL
            ORDER BY OVERDUE DESC, PENDING DESC
        """)
        leader_stats = cursor.fetchall()

        cursor.execute("""
            SELECT u.DEPT_CODE, AVG(f.SAT_SCORE_INT) as DEPT_SAT, COUNT(f.ID) as COUNT
            FROM USERS u JOIN FEEDBACK f ON u.EMAIL = f.EMAIL
            WHERE f.SUBMISSION_PERIOD = %s 
            GROUP BY u.DEPT_CODE
        """, (period,))
        depts = cursor.fetchall()
        
        return templates.TemplateResponse("senior_dashboard.html", {
            "request": request, "view": "org", "stats": stats, "depts": depts, 
            "leader_stats": leader_stats, # New data
            "current_period": period, "available_periods": available_periods, "email": email
        })
    else:
        # --- DEPT VIEW ---
        cursor.execute("""
            SELECT f.*, u.FULL_NAME, u.MANAGER_EMAIL, r.FEEDBACK_ID as REVIEWED
            FROM FEEDBACK f
            JOIN USERS u ON f.EMAIL = u.EMAIL
            LEFT JOIN MANAGER_REVIEWS r ON f.ID = r.FEEDBACK_ID
            WHERE u.DEPT_CODE = %s AND f.SUBMISSION_PERIOD = %s
        """, (dept, period))
        dept_employees = cursor.fetchall()
        
        return templates.TemplateResponse("senior_dashboard.html", {
            "request": request, "view": "dept", "dept_name": dept, "employees": dept_employees,
            "current_period": period, "available_periods": available_periods, "email": email
        })
        


@app.post("/delete_action/{action_id}")
async def delete_action(action_id: int, db=Depends(get_db)):
    try:
        cursor = db.cursor()
        cursor.execute("DELETE FROM MANAGER_ACTIONS WHERE ACTION_ID = %s", (action_id,))
        db.commit()
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "detail": str(e)}, 500
        
@app.post("/update_action/{action_id}")
async def update_action(action_id: int, request: Request, db=Depends(get_db)):
    try:
        data = await request.json()
        new_status = data.get('status') # Should be 'Pending' or 'Completed'
        
        cursor = db.cursor()
        cursor.execute("""
            UPDATE MANAGER_ACTIONS 
            SET STATUS = %s 
            WHERE ACTION_ID = %s
        """, (new_status, action_id))
        
        db.commit() # This ensures the "uncheck" is permanent
        return {"status": "success"}
    except Exception as e:
        print(f"Update error: {e}")
        return {"status": "error", "detail": str(e)}, 500

@app.post("/add_action")
async def add_action(request: Request, db=Depends(get_db)):
    data = await request.json()
    cursor = db.cursor()
    cursor.execute("""
        INSERT INTO MANAGER_ACTIONS (EMP_EMAIL, MGR_EMAIL, TASK_DESCRIPTION, STATUS, DUE_DATE)
        VALUES (%s, %s, %s, 'Pending', %s)
    """, (data['emp_email'], data['mgr_email'], data['task'], data.get('due_date')))
    db.commit()
    return {"status": "success"}

@app.post("/edit_action/{action_id}")
async def edit_action(action_id: int, request: Request, db=Depends(get_db)):
    try:
        data = await request.json()
        cursor = db.cursor()
        
        # Update both the text AND the due date
        cursor.execute("""
            UPDATE MANAGER_ACTIONS 
            SET TASK_DESCRIPTION = %s, 
                DUE_DATE = %s 
            WHERE ACTION_ID = %s
        """, (data['task'], data.get('due_date'), action_id))
        
        db.commit()
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "detail": str(e)}, 500